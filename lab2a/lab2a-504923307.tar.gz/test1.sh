#! /bin/bash

declare -a iter
declare -a thread
declare -a yield
declare -a locks

iter=(100 1000 10000 100000)

thread[0]=2
thread[1]=4
thread[2]=8
thread[3]=12

truncate -s 0 lab2_add.csv
truncate -s 0 lab2_list.csv
#add-1 and add-2
for i in "${iter[@]}"; do
   for j in "${thread[@]}"; do
        ./lab2_add --iterations=$i --threads=$j >> lab2_add.csv
    done
done 

iter=(10 20 40 80 100 1000 10000 100000)
for i in "${iter[@]}"; do
   for j in "${thread[@]}"; do
        ./lab2_add --iterations=$i --threads=$j --yield >> lab2_add.csv
    done
done 

#add-3
for i in "${iter[@]}"; do
    ./lab2_add --iterations=$i --threads=1 >> lab2_add.csv
done

#add-4
for i in "${thread[@]}"; do
     ./lab2_add --iterations=10000 --threads=$i --sync=m --yield >> lab2_add.csv
     ./lab2_add --iterations=10000 --threads=$i --sync=c --yield >> lab2_add.csv
     ./lab2_add --iterations=1000 --threads=$i --sync=s --yield >> lab2_add.csv
done

#add-5
thread=( 1 2 4 8 12 )
for i in "${thread[@]}"; do
    ./lab2_add --iterations=10000 --threads=$i --sync=m --yield >> lab2_add.csv
    ./lab2_add --iterations=10000 --threads=$i --sync=c --yield >> lab2_add.csv
    ./lab2_add --iterations=10000 --threads=$i --sync=s --yield >> lab2_add.csv
done
for i in "${thread[@]}"; do
    ./lab2_add --iterations=10000 --threads=$i --sync=m >> lab2_add.csv
    ./lab2_add --iterations=10000 --threads=$i --sync=c >> lab2_add.csv
    ./lab2_add --iterations=10000 --threads=$i --sync=s >> lab2_add.csv
done


#########list#########

#list-1
iter=( 10 100 1000 10000 20000 )
for i in "${iter[@]}"; do
    ./lab2_list --iterations=$i --threads=1 >> lab2_list.csv
done

#list-2
iter=( 1 10 100 1000 )
thread=( 2 4 8 12 )
for i in "${thread[@]}"; do
    for j in "${iter[@]}"; do
        ./lab2_list --iterations=$j --threads=$i >> lab2_list.csv
    done
done

iter=( 1 2 4 8 16 32 )
yield=( "i" "d" "il" "dl" )
for i in "${thread[@]}"; do
    for j in "${iter[@]}"; do
        for k in "${yield[@]}"; do
            ./lab2_list --iterations=$j --threads=$i --yield=$k >> lab2_list.csv
        done
    done
done

#iter-3
iter=( 1 2 4 8 16 32 )
thread=( 2 4 8 12 )
for i in "${thread[@]}"; do
    for j in "${iter[@]}"; do
        for k in "${yield[@]}"; do
            ./lab2_list --iterations=$j --threads=$i --yield=$k >> lab2_list.csv
            ./lab2_list --iterations=$j --threads=$i --yield=$k --sync=m >> lab2_list.csv
            ./lab2_list --iterations=$j --threads=$i --yield=$k --sync=s >> lab2_list.csv
        done
    done
done

#iter-4 iter-5
thread=( 1 2 4 8 12 16 24 )
iter=( 1000 )
for i in "${thread[@]}"; do
    for j in "${iter[@]}"; do
        ./lab2_list --iterations=$j --threads=$i --sync=m >> lab2_list.csv
        ./lab2_list --iterations=$j --threads=$i --sync=s >> lab2_list.csv
    done
done